#ifndef _FIELDFLAT_H
#define _FIELDFLAT_H

#include "common.h"
#include "fluxdata.h"

void flatten_field(FluxWappData * wappdata, float nsigma, int order);

#endif 
