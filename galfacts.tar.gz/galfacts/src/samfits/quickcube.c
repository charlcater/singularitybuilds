#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fitsio.h"

int main(int argc, char *argv[]) 
{

	int f,N1,N2,n1,n2,i,i1,j,k,numfiles;
	char outcube_name[40];
	char * incube_name;
	char * listfilename;
	FILE * incube_file;
	FILE * outcube_file;
	header_param_list incube_hpar;
	//header_param_list outcube_hpar;
	int inplane_len;
	int outplane_len;
	int outdata_len,xcount,ycount;
	float * inplane_data;
	float * outplane_data;
	float * outcube_data;
	char ** incubes;
	float start;

	incube_file = fopen(incubes[f], "r");
	if(incube_file == NULL)
		printf("Failed to open file\n");
	readfits_header(incube_file, &incube_hpar);
	printf("Reading %s\n",incubes[f]);
	
	outdata_len = incube_hpar.naxis[0]/10 * incube_hpar.naxis[1]/2 * 1700;
	if(f ==0)
	{
		outcube_data = (float*) calloc(outdata_len, sizeof (float));
		outplane_len = incube_hpar.naxis[0]/10 * incube_hpar.naxis[1]/2;
		start =  incube_hpar.crval[2];
	}
	inplane_len = incube_hpar.naxis[0] * incube_hpar.naxis[1];
	inplane_data = (float*) calloc(inplane_len, sizeof (float));
	N1 = incube_hpar.naxis[0];
	n1 = incube_hpar.naxis[0]/10;
	N2 = incube_hpar.naxis[1];
	n2 = incube_hpar.naxis[1]/2;
	//iterate over the cube
	//for (i=0,i1=0; i<incube_hpar.naxis[2]; i=i+2,i1++) 
	for (i=0; i<incube_hpar.naxis[2];i++) 
	{
		//read a plane
		//printf("Plane %d\n",i);
		readfits_plane(incube_file, inplane_data, &incube_hpar);
		//readfits_plane(incube_file, inplane_data, &incube_hpar);
		//include in average only if stated in frames
		for(j=0;j<n2;j++)
		{
			//printf("%i \n", i);
			for (k=0; k<n1; k++) 
			{
				//add to average and increment count if its not blank
					outcube_data[j*n1+k+i*outplane_len+f*outplane_len*incube_hpar.naxis[2]] = inplane_data[j*incube_hpar.naxis[0]+k+n1*xcount+ycount*incube_hpar.naxis[0]*n2];
					//outcube_data[j*n1+k+i1*outplane_len+f*outplane_len*incube_hpar.naxis[2]/2] = inplane_data[j*incube_hpar.naxis[0]+k+n1*xcount+ycount*incube_hpar.naxis[0]*n2];
			}
		}
	}
	free(inplane_data);
	fclose(incube_file);
	}
	
	float Xcen,Ycen;
	Xcen = incube_hpar.crval[0];
	Ycen = incube_hpar.crval[1];
	//write the average fits
        incube_hpar.crval[0] = Xcen - N1*(incube_hpar.cdelt[0])/2+(2*xcount+1)*(incube_hpar.cdelt[0])*n1/2;         /* degrees */
        incube_hpar.crval[1] = Ycen - N2*(incube_hpar.cdelt[1])/2+(2*ycount+1)*(incube_hpar.cdelt[1])*n2/2;         /* degrees */
        incube_hpar.crpix[0] = 0.5 + n1 / 2.0;        /* image center in pixels */
        incube_hpar.crpix[1] = 0.5 + n2 / 2.0;
	//incube_hpar.naxis[2] = 900;
	incube_hpar.naxis[2] = 1700;
	incube_hpar.naxis[0] /= 10;
	incube_hpar.naxis[1] /= 2;
	incube_hpar.crval[2] = start;
	//incube_hpar.cdelt[2] *= 2;
	//strcat(cube_hpar.object, " Average");
	//printf("Writing output cube fstart %f\n",start);
	sprintf(outcube_name,"D%d_Qcube.fits",xcount+ycount*10+1);
	printf("Writing %s\n",outcube_name);
	writefits_cube(outcube_name, outcube_data, &incube_hpar,0);
	return EXIT_SUCCESS;
}
