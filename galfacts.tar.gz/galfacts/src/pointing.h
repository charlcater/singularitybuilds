#include "common.h"

#ifndef _POINTING_H
#define _POINTING_H

void create_annotations(SpecRecord dataset[], int size);

#endif //_POINTING_H

