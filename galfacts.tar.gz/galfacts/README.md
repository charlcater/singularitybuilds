GALFACTS pipeline
========

This repository contains the code to process the GALFACTS data. 
