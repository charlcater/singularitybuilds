#include "common.h"
#include "fluxdata.h"
#include "map.h"

#ifndef _PACORR_H
#define _PACORR_H

void pa_corr(FluxWappData * wappdata, int chan, MapMetaData *md);
#endif
