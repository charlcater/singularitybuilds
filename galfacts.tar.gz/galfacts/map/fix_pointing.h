#include "common.h"
#include "fluxdata.h"
#include "map.h"

#ifndef _FIX_POINTING_H
#define _FIX_POINTING_H

void fix_pointing(const char *field, FluxWappData *wappdata);

#endif
