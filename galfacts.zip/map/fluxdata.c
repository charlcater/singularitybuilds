#include "map.h"
#include "fluxdata.h"
#include "jsd/jsd_futil.h"
#include <string.h>
#include <values.h>
#include <math.h>
#include <fcntl.h>

extern int multibeam;


static float n1racoeffs[7] = {
	0,
	2.7417,
	5.4833,
	2.7417,
	-2.7417,
	-5.4833,
	-2.7417,
};


static int is_central_beam(int beam)
{
	return beam == 0;
}


static int is_outer_beam(int beam)
{
	return beam > 0;
}


static float calc_n1_outer_ra(
	const int beam,
	const float central_ra,
	const float outer_dec_radians)
{
	return central_ra + n1racoeffs[beam]/(60*cos(outer_dec_radians));
}


static int needs_n1_pointing_fix(
	const char *field,
	const int mjd)
{
	return field[0] == 'N' && field[1] == '1' && mjd <= 54889;
}


int fluxrecord_read_binary(FluxRecord * pRec, FILE * file)
{
	int k = 0;

	k += fread(&pRec->RA, sizeof(float), 1, file);
	k += fread(&pRec->DEC, sizeof(float), 1, file);
	k += fread(&pRec->AST, sizeof(float), 1, file);
	k += fread(&pRec->stokes.I, sizeof(float), 1, file);
	k += fread(&pRec->stokes.Q, sizeof(float), 1, file);
	k += fread(&pRec->stokes.U, sizeof(float), 1, file);
	k += fread(&pRec->stokes.V, sizeof(float), 1, file);

	return k;
}


FluxWappData * fluxwappdata_alloc(const char *wapp, char **days, int numDays)
{
	int i,j;
	FluxWappData * wappdata;

	wappdata = (FluxWappData*) malloc(sizeof(FluxWappData));

	strncpy(wappdata->wapp, wapp, WAPP_LEN);
	wappdata->numDays = numDays;
	wappdata->daydata = (FluxDayData*) malloc(sizeof(FluxDayData) * numDays);
	wappdata->scanDayData = (ScanDayData*) malloc(sizeof(ScanDayData) * numDays);

	for (i=0; i<numDays; i++) 
	{
		if (!strcmp(wapp,"multibeam"))
		{
			j = i/7;
			strncpy(wappdata->daydata[i].mjd, days[j], MJD_LEN);
		}
		else
		{
			strncpy(wappdata->daydata[i].mjd, days[i], MJD_LEN);
		}

		wappdata->daydata[i].numRecords = 0;
		wappdata->daydata[i].records = NULL;
		wappdata->scanDayData[i].numScans = 0;
		wappdata->scanDayData[i].scans = NULL;
	}

	return wappdata;
}


void fluxwappdata_free(FluxWappData * wappdata)
{
	int i;
	if (wappdata == NULL)
		return;

	if (wappdata->daydata != NULL)
	{
		for (i=0; i<wappdata->numDays; i++) 
		{
			if (wappdata->daydata[i].records != NULL) 
			{
				free(wappdata->daydata[i].records);
				wappdata->daydata[i].records = NULL;
			}
		}

		free(wappdata->daydata);
		wappdata->daydata = NULL;
	}

	free(wappdata);
}


int fluxdaydata_read_binary(const char *field, FluxDayData *daydata,
	FILE *infile, int beam, int chan, int day,
	const float ramin, const float ramax)
{
	int numRecords;
	int badCount = 0;
	char header[80+1];

	// to keep track of the smallest and largest RA values encountered,
	// which still fall within the configured RA bounds of the field.
	float min_ra_read = FLT_MAX;
	float max_ra_read = FLT_MIN;

	fread(&numRecords, sizeof(int), 1, infile); 

	if (daydata->records != NULL)
		free(daydata->records);

	daydata->records = (FluxRecord*) malloc(numRecords * sizeof(FluxRecord));

	if (daydata->records == NULL)
	{
		printf("ERROR: Malloc failed.\n");
		exit(1);
	}
	
	// read and process bad data file

	FILE *baddatafile = fopen("Baddata.list","rt");
	if (baddatafile != NULL)
		printf("INFO: Day %d opened with fd %d.\n", day, *baddatafile);

	float lowRA = 0.0, highRA = 0.0;
	int badmjd = 0, badlowchan = 0, badhighchan = 0, bad = 0;
	char badbeam[8] = {0};

	if (baddatafile != NULL)
	{
		//read out the #header
		fgets(header, 80, baddatafile);

		while (!feof(baddatafile))
		{
			// read out a line of bad data file
			fscanf(baddatafile,"%d %s %d %d %f %f", &badmjd, badbeam, &badlowchan,
				&badhighchan, &lowRA, &highRA);

			if ((badmjd == day) && (badbeam[beam] == '1') && (chan >= badlowchan)
				&& (chan <= badhighchan))
			{
				// MJDs, beams and chans match, so we've found
				// the RA range of today's bad data.
				bad = 1;
				break;
			}
		}

		if (!bad)
		{
			// no baddata lines found for this mjd+beam+channel so close the file
			fclose(baddatafile);
			baddatafile = NULL;
		}
	}
	else
	{
		bad = 0;
	}

	// pointing data was wrong for initial N1 observation.
	// see the `fluxdaydata_read_binary_single_file` 
	int n1fix = needs_n1_pointing_fix(field, day);

	int n1_goodish = (54886 <= day) && (day <= 54889);

	static float central_ra[200000], central_dec[200000], central_ast[200000];

	static int n_central_k = 0; // number of values in central beam

	// number of records discarded because no corresponding record was
	// found in beam 0:
	int n1_num_discarded = 0;

	if (n1fix && is_central_beam(beam))
	{
		// reset the count since this is a new day
		n_central_k = 0;
	}

	if (n1fix && beam > 6)
	{
		printf("ERROR: Invalid beam encountered: %d\n", beam);
		fflush(stdout);
		exit(1);
	}

	// Read records for this channel from average file:

	// `k` keeps track of current record in memory. `nrecread` keep track
	// of the number of records read from the file. Some records will be
	// discarded, so `k == nrecread` isn't guaranteed. In the end, only
	// `k` records will be loaded into memory.
	int k = 0;
	int nrecread = 0;
	int flag = 0;
	int central_k = 0;

	while (!feof(infile) && nrecread<numRecords)
	{
		FluxRecord *pRec = &daydata->records[k];

		int num = fluxrecord_read_binary(pRec, infile);
		nrecread++;

		if (num==0)
		{
			// [kevin] Is this still valid? I suspect we should rather break here.

			//fix for certain missing data in beam 0 (a real pain!)
			continue;
		}

		if (num < 0)
		{
			break;
		}

		if (num != 7)
		{
			printf("ERROR: Corrupt average flux file. Read only %i fields from record.\n", num);
			exit(1);
		}

		float RA = daydata->records[k].RA;
		float DECR = daydata->records[k].DEC*M_PI/180.0;

		if (max_ra_read < RA && RA < ramax)
		{
			// keep track of the largest encountered RA value
			// that still falls within the configured RA bounds
			// of the field.
			max_ra_read = RA;
		}

		if (RA < min_ra_read)
		{
			// do the same for the smallest encountered RA value
			// but don't check configured lower bound for this fix,
			// just to stay as close as possible to original logic.
			// should be revisited after 3.1.2 data release.
			min_ra_read = RA;
		}

		if (n1fix && is_central_beam(beam))
		{
			central_ra[central_k] = pRec->RA;
			central_dec[central_k] = pRec->DEC;
			central_ast[central_k] = pRec->AST;
			central_k++;
			n_central_k++;

			if (central_k > 200000)
			{
				printf("ERROR: N1 pointing fix array overrun.\n");
				fflush(stdout);
				exit(1);
			}
		}

		if (n1fix && is_outer_beam(beam))
		{
			if (!n1_goodish)
			{
				while (central_k < n_central_k && central_ast[central_k] < daydata->records[k].AST)
				{
					central_k++;
				}
			}
			
			if (central_k >= n_central_k)
			{
				printf("WARNING: End of beam 0 data reached during N1 pointing fix.\n");
				break;
			}
			
			if (central_ast[central_k] != daydata->records[k].AST)
			{
				// Central AST ahead of outer, so skip this record.
				n1_num_discarded++;
				continue;
			}

			daydata->records[k].RA = calc_n1_outer_ra(beam, central_ra[central_k], DECR);
			central_k++;
		}

		if (bad && daydata->records[k].RA > highRA && baddatafile != NULL && (ramax < 360.0 || daydata->records[k].RA <= ramax))
		{
			if (!feof(baddatafile))
			{
				// read out a line of bad data file
				fscanf(baddatafile,"%d %s %d %d %f %f", &badmjd, badbeam, &badlowchan, &badhighchan, &lowRA, &highRA);

				if ((badmjd == day) && (badbeam[beam] == '1') && (chan >= badlowchan) && (chan <= badhighchan))
				{
					// MJDs, beams and chans match,
					// so we've found the next RA
					// range of today's bad data.
					bad = 1;
				}
				else
				{
					bad = 0;
					fclose(baddatafile);
				}
			}
			else
			{
				bad = 0;
				fclose(baddatafile);
			}
		}

		if (bad && daydata->records[k].RA>=lowRA && daydata->records[k].RA<=highRA)
		{
			daydata->records[k].stokes.I = NAN;
			daydata->records[k].stokes.Q = NAN;
			daydata->records[k].stokes.U = NAN;
			daydata->records[k].stokes.V = NAN;
			badCount++;
		}

		if (ramax < 360.0 || daydata->records[k].RA < ramax)
		{
			// 24h wrapping fix: N4 has some high-RA records which cause
			// streaky artefacts around the 0h line. This filtering works,
			// but there might be a better way to do this earlier in the
			// pipeline. also, we may want to filter ALL fields, not just
			// those with RAMAX >= 360?
			k++;
		}
	}

	daydata->numRecords = k;
	daydata->RAmin = min_ra_read;
	daydata->RAmax = max_ra_read;

	return k;
}


int fluxdaydata_read_binary_single_file(const char *field, FluxDayData *daydata,
	FILE *infile, FILE *configfile, int beam, int chan, int day,
	const float ramin, const float ramax)
{
	int numRecords;
	int badCount = 0;
	char header[80+1];
	int k = 0;
	int channelcount;
	int configlines;
	int *records;
	int numRead;
	int cfgChan, cfgStart, cfgNumRecords;
	char filename[64];

	// to keep track of the smallest and largest RA values encountered,
	// which still fall within the configured RA bounds of the field.
	float min_ra_read = FLT_MAX;
	float max_ra_read = FLT_MIN;

	// for single file processing, we need the config file or fail and exit
	// even missing channels will have NANs to read
	if (configfile != NULL)
	{
		do
		{
			numRead = fscanf(configfile, "%d %d %d\n", &cfgChan, &cfgStart, &cfgNumRecords);

			if (numRead == 3)
			{
				if (cfgChan == chan)
				{
					//found the channel we are looking for
					break;
				}
			}
			else
			{
				printf("ERROR: Corrupt fluxtime config file. Read %d records instead of 3.\n", numRead);
				exit(1);
			}
		}
		while (!feof(configfile) && (cfgChan < chan));

		if (cfgChan != chan)
		{
			printf("ERROR: Channel data not found: chan = %d, cfgChan %d.\n", chan, cfgChan);
			exit(1);
		}

	}
	else
	{
		if (chan != 0)
		{
			printf("ERROR: No fluxtime config found for %d %d %d\n", day, beam, chan);
			exit(1);
		}
	}

	// we could assume numRecords never changes, but just in case
	numRecords = cfgNumRecords;

	if (daydata->records != NULL)
		free(daydata->records);

	daydata->records = (FluxRecord*) malloc(numRecords * sizeof(FluxRecord));

	if (daydata->records == NULL)
	{
		printf("ERROR: Malloc failed.\n");
		exit(1);
	}

	// read and process bad data file

	FILE *baddatafile = fopen("Baddata.list","rt");
	if (baddatafile != NULL)
		printf("INFO: Day %d opened with fd %d.\n", day, *baddatafile);

	float lowRA = 0.0, highRA = 0.0;

	int badmjd = 0, badlowchan = 0, badhighchan = 0, bad = 0;
	char badbeam[8] = {0};

	if (baddatafile != NULL)
	{
		//read out the #header
		fgets(header, 80, baddatafile);

		while (!feof(baddatafile))
		{
			// read out a line of bad data file
			fscanf(baddatafile,"%d %s %d %d %f %f", &badmjd, badbeam, &badlowchan,
				&badhighchan, &lowRA, &highRA);

			if ((badmjd == day) && (badbeam[beam] == '1') && (chan >= badlowchan)
				&& (chan <= badhighchan))
			{
				// MJDs, beams and chans match, so we've found
				// the RA range of today's bad data.
				bad = 1;
				break;
			}
		}

		if (!bad)
		{
			fclose(baddatafile);
			baddatafile = NULL;
		}
	}
	else
	{
		bad = 0;
	}

	// seek to right record, without overflowing the long
	long recordSize = sizeof(float) * 7;
	int ret = fseek(infile, recordSize * cfgStart, SEEK_SET);

	if (ret != 0)
	{
		printf("ERROR: Error seeking in binary file with error %d.\n", ret);
	}

	// Pointing values of outer beams were wrong during initial N1
	// observation. To fix this, we store the beam0 pointing between
	// invocations of this method and estimate the outer pointing based
	// on this.
	
	// NOTE: This means that this method assumes beam 0 of a day will
	// always be processed first, and an entire day will be processed
	// before moving on to another day.
	// [kevin] This code is extremely hairy, but I don't want to make
	// project-wide changes to the logic until 3.1.2 is fully released.

	int n1fix = needs_n1_pointing_fix(field, day);

	// Timestamps for some of the initial observations crossed the midnight
	// line, which makes the N1 fix very complicated. Luckily these beams
	// didn't misbehave like 54787, which has data missing in beam0. So
	// we'll treat them as a special case:
	int n1_goodish = (54886 <= day) && (day <= 54889);

	static float central_ra[200000], central_dec[200000], central_ast[200000];

	static int n_central_k = 0; // number of values in central beam

	// number of records discarded because no corresponding record was
	// found in beam 0:
	int n1_num_discarded = 0;

	if (n1fix && is_central_beam(beam))
	{
		// reset the count since this is a new day
		n_central_k = 0;
	}

	if (n1fix && beam > 6)
	{
		printf("ERROR: Invalid beam encountered: %d\n", beam);
		fflush(stdout);
		exit(1);
	}

	// Read all the records for this channel from the fluxdata file:

	// `k` is the current index in memory - where the current  record is
	// stored. `nrecread` is the number of records read from file. Some
	// will be discarded, so `k == nrecread` isn't guaranteed.
	// In the end, only `k` records will be loaded into memory.
	k = 0;
	int nrecread = 0;
	int flag = 0;
	int central_k = 0;

	while (!feof(infile) && nrecread < numRecords)
	{
		FluxRecord *pRec = &daydata->records[k];

		// read the floats from the file after seeking to channel
		int num = fluxrecord_read_binary(pRec, infile);
		nrecread++;

		if (num==0)
		{
			// [kevin] Is this still valid? I suspect we should rather break here.

			//fix for certain missing data in beam 0 (a real pain!)
			continue;
		}

		if (num < 0)
		{
			break;
		}

		if (num != 7)
		{
			printf("ERROR: Corrupt flux file. Read only %i fields from record.\n", num);
			exit(1);
		}
			
		float DECR = daydata->records[k].DEC*M_PI/180.0;

		if (n1fix && is_central_beam(beam))
		{
			central_ra[central_k] = pRec->RA;
			central_dec[central_k] = pRec->DEC;
			central_ast[central_k] = pRec->AST;
			central_k++;
			n_central_k++;

			if (central_k > 200000)
			{
				printf("ERROR: N1 pointing fix array overrun.\n");
				fflush(stdout);
				exit(1);
			}
		}

		if (n1fix && is_outer_beam(beam))
		{
			if (!n1_goodish)
			{
				while (central_k < n_central_k && central_ast[central_k] < daydata->records[k].AST)
				{
					// Outer beam is ahead of central, so catch up.
					central_k++;
				}
			}

			if (central_k >= n_central_k)
			{
				printf("WARNING: End of beam 0 reached while performing N1 pointing fix.\n");
				break;
			}

			if (central_ast[central_k] != daydata->records[k].AST)
			{
				// Central beam is ahead of outer, so discard
				// this record and try the next one.
				// Didn't use `greater than` because the
				// "goodish" days aren't monotonically increasing.
				n1_num_discarded++;
				continue;
			}

			daydata->records[k].RA = calc_n1_outer_ra(beam, central_ra[central_k], DECR);
			central_k++;
		}

		float RA = daydata->records[k].RA;
		if (max_ra_read < RA && RA < ramax)
		{
			// keep track of the largest encountered RA value
			// that still falls within the configured RA bounds
			// of the field.
			max_ra_read = RA;
		}

		if (RA < min_ra_read)
		{
			// do the same for the smallest encountered RA value
			// but don't check configured lower bound for this fix,
			// just to stay as close as possible to original logic.
			// should be revisited after 3.1.2 data release.
			min_ra_read = RA;
		}

		if (bad && daydata->records[k].RA > highRA && baddatafile != NULL
			&& (ramax < 360.0 || daydata->records[k].RA <= ramax))
		{
			if (!feof(baddatafile))
			{
				// read out a line of bad data file
				fscanf(baddatafile,"%d %s %d %d %f %f", &badmjd, badbeam, &badlowchan, &badhighchan, &lowRA, &highRA);

				if ((badmjd == day) && (badbeam[beam] == '1')
					&& (chan >= badlowchan) && (chan <= badhighchan))
				{
					// MJDs, beams and channels match,
					// so we've found the RA range
					// for today's bad data.
					bad = 1;
				}
				else
				{
					bad = 0;
					fclose(baddatafile);
				}
			}
			else
			{
				bad = 0;
				fclose(baddatafile);
			}
		}

		if (bad && daydata->records[k].RA>=lowRA && daydata->records[k].RA<=highRA)
		{
			daydata->records[k].stokes.I = NAN;
			daydata->records[k].stokes.Q = NAN;
			daydata->records[k].stokes.U = NAN;
			daydata->records[k].stokes.V = NAN;
			badCount++;
		}

		if (ramax < 360.0 || daydata->records[k].RA < ramax)
		{
			// 24h wrapping fix: N4 has some high-RA records which cause
			// streaky artefacts around the 0h line. This filtering works,
			// but there might be a better way to do this earlier in the
			// pipeline. also, we may want to filter ALL fields, not just
			// those with RAMAX >= 360?
			k++;
		}
	}

	daydata->numRecords = k;
	daydata->RAmin = min_ra_read;
	daydata->RAmax = max_ra_read;

	return k;
}


// TODO: Clean up this code! [kevin]
void fluxwappdata_readchan_binary(
	const char *field, int band, FluxWappData * wappdata, int chan, int id,
	int avg, float decmin, float decmax, const float ramin, const float ramax)
{

const float dec_step_expected = 0.005;
const float dec_step_tolerance = 0.001;
const float min_dec_step = dec_step_expected - dec_step_tolerance;
const float max_dec_step = dec_step_expected + dec_step_tolerance;
int  m,j,n, i, numread, flag = 0, navg;
FILE *infile, *configfile;
char beamno[6];
float weight = 0;

float interp[10] = {1.23376620, 1.18181813, 1.12987018, 1.07792211, 1.02597404, 0.97402596, 0.92207789, 0.87012988, 0.81818181, 0.76623374};

if(avg == 0) navg = 1; else navg = avg;

for(m=0; m<wappdata->numDays; m++)
	{
	printf("Reading Day %d\n",m);
	fflush(stdout);
	FluxDayData * daydata = &wappdata->daydata[m];	
	FluxDayData * tempdata_avg = NULL;
	if(tempdata_avg == NULL) 
		{
		tempdata_avg = malloc(sizeof(FluxDayData));
		tempdata_avg->records = NULL;
		}
	flag = 0;
	for(n=0; n<navg; n++)
		{
		FluxDayData * tempdata = NULL;
		if(tempdata == NULL) 
			{
			tempdata = malloc(sizeof(FluxDayData));
			tempdata->records = NULL;
			}
		char filename[64+1];
		char configfilename[64+1];
		if(!strcmp(wappdata->wapp,"multibeam"))
		{
			j = m%7;
			sprintf(beamno,"beam%d",j);
			if(id == CLEAN)
			{
				sprintf(filename, "%s/%s/balance.dat", daydata->mjd, beamno);
				sprintf(configfilename, "%s/%s/balance.dat_cfg", daydata->mjd, beamno);

			}
			if(id == BASKETWEAVE)
			{
				sprintf(filename, "%s/%s/fluxtime.dat", daydata->mjd, beamno);
				sprintf(configfilename, "%s/%s/fluxtime.dat_cfg", daydata->mjd, beamno);
			}
		}
		else
		{
			j = atoi(&wappdata->wapp[4]);
			sprintf(beamno,"beam%d",j);
			if(id == CLEAN)
			{
				sprintf(filename, "%s/%s/balance.dat", daydata->mjd, wappdata->wapp);
				sprintf(configfilename, "%s/%s/balance.dat_cfg", daydata->mjd, wappdata->wapp);

			}
			if(id == BASKETWEAVE)
			{
				sprintf(filename, "%s/%s/fluxtime.dat", daydata->mjd, wappdata->wapp);
				sprintf(configfilename, "%s/%s/fluxtime.dat_cfg", daydata->mjd, wappdata->wapp);
			}
		}
		infile = fopen(filename, "rb");
		configfile = fopen(configfilename, "r");
		if( configfile == NULL ) printf("ERROR: configfile is NULL\n");
		if(infile != NULL) 
			{
			// we are looking for average image, read average.dat instead
			if( chan == 0 && avg == 0 ) {
				fclose( infile );
				infile = NULL;
				sprintf(filename, "%s/%s/average.dat", daydata->mjd, beamno);
				FILE * avgfile = fopen(filename, "rb");

				if( avgfile != NULL )
				{
					numread = fluxdaydata_read_binary(
						field, tempdata, avgfile, j, 0, atoi(daydata->mjd),
						ramin, ramax);
					fclose(avgfile);
				}
				else
				{
					printf("Error. Looking for %s for average image, failed. Exitting.\n",filename);
					exit(1);

				}
			}
			else
			{
				numread = fluxdaydata_read_binary_single_file(
					field, tempdata, infile, configfile, j, chan+n,
					atoi(daydata->mjd), ramin, ramax);
			}
			printf("Opened file %s\n",filename);
			printf("read %d records.\n",tempdata->numRecords );
			if (infile != NULL) {
				fclose(infile);
			}
			fclose(configfile);
			if(n==0)
				{			
				if(tempdata_avg->records != NULL) free(tempdata_avg->records);	
				tempdata_avg->records = (FluxRecord*) malloc(tempdata->numRecords * sizeof(FluxRecord));
				tempdata_avg->numRecords = tempdata->numRecords;
				tempdata_avg->RAmin = tempdata->RAmin;
				tempdata_avg->RAmax = tempdata->RAmax;	
				for(i=0; i<numread; i++)
					{
					tempdata_avg->records[i].RA = tempdata->records[i].RA;
					tempdata_avg->records[i].DEC = tempdata->records[i].DEC;
					tempdata_avg->records[i].AST = tempdata->records[i].AST;
					tempdata_avg->records[i].stokes.I = 0.0;
					tempdata_avg->records[i].stokes.Q = 0.0;
					tempdata_avg->records[i].stokes.U = 0.0;
					tempdata_avg->records[i].stokes.V = 0.0;
					tempdata_avg->records[i].count = 0;
					tempdata_avg->records[i].weight = 0;
					}
				}	
			for(i=0; i<numread; i++)
			{
				if(isfinite(tempdata->records[i].stokes.I))
				{
					if( band == 1 )
					{
						tempdata_avg->records[i].stokes.I += tempdata->records[i].stokes.I*interp[n];
						tempdata_avg->records[i].stokes.Q += tempdata->records[i].stokes.Q*interp[n];
						tempdata_avg->records[i].stokes.U += tempdata->records[i].stokes.U*interp[n];
						tempdata_avg->records[i].stokes.V += tempdata->records[i].stokes.V*interp[n];
						tempdata_avg->records[i].weight += interp[n];
						tempdata_avg->records[i].count++;
					}
					else
					{
						tempdata_avg->records[i].stokes.I += tempdata->records[i].stokes.I;
						tempdata_avg->records[i].stokes.Q += tempdata->records[i].stokes.Q;
						tempdata_avg->records[i].stokes.U += tempdata->records[i].stokes.U;
						tempdata_avg->records[i].stokes.V += tempdata->records[i].stokes.V;
						tempdata_avg->records[i].count++;
					}
				}
			}
			free(tempdata->records);
			}
		else
			{
			flag++;
			printf("Error could not open file %s\n",filename);
			}
		free(tempdata);
		}
	if(flag < navg)
		{
		for(i=0; i<numread; i++)
			{
			if(tempdata_avg->records[i].count > 0)
				{
					if( band == 1 )
					{
						tempdata_avg->records[i].stokes.I /= tempdata_avg->records[i].weight;
						tempdata_avg->records[i].stokes.Q /= tempdata_avg->records[i].weight;
						tempdata_avg->records[i].stokes.U /= tempdata_avg->records[i].weight;
						tempdata_avg->records[i].stokes.V /= tempdata_avg->records[i].weight;
					}
					if ( band == 0 )
					{
						tempdata_avg->records[i].stokes.I /= tempdata_avg->records[i].count;
						tempdata_avg->records[i].stokes.Q /= tempdata_avg->records[i].count;
						tempdata_avg->records[i].stokes.U /= tempdata_avg->records[i].count;
						tempdata_avg->records[i].stokes.V /= tempdata_avg->records[i].count;
					}
				}
				else
				{
					tempdata_avg->records[i].stokes.I = NAN;
					tempdata_avg->records[i].stokes.Q = NAN;
					tempdata_avg->records[i].stokes.U = NAN;
					tempdata_avg->records[i].stokes.V = NAN;
				}
			}
		daydata->records = (FluxRecord*) malloc(tempdata_avg->numRecords * sizeof(FluxRecord));
		daydata->RAmin = tempdata_avg->RAmin;
		daydata->RAmax = tempdata_avg->RAmax;
		int jj = 0; 
		for(i=0; i < numread; i++)
			{
			int moonflag = 0;
			if(isfinite(tempdata_avg->records[i].stokes.I))
				{
				daydata->records[jj].stokes.I = tempdata_avg->records[i].stokes.I;
				daydata->records[jj].stokes.Q = tempdata_avg->records[i].stokes.Q;
				daydata->records[jj].stokes.U = tempdata_avg->records[i].stokes.U;
				daydata->records[jj].stokes.V = tempdata_avg->records[i].stokes.V;
				daydata->records[jj].RA = tempdata_avg->records[i].RA;
				daydata->records[jj].DEC = tempdata_avg->records[i].DEC;
				daydata->records[jj].AST = tempdata_avg->records[i].AST;				

// Just for N1
// ----------------------
		if(field[0] == 'N' && field[1] == '1')
			{
				if(!strcmp(daydata->mjd,"54811") && (tempdata_avg->records[i].AST > 9505)  && (tempdata_avg->records[i].AST < 9580)) moonflag = 1;
				if(!strcmp(daydata->mjd,"54812") && (tempdata_avg->records[i].AST > 13475)  && (tempdata_avg->records[i].AST < 13555)) moonflag = 1;
				if(!strcmp(daydata->mjd,"54793") && ((tempdata_avg->records[i].RA < 42.0 && tempdata_avg->records[i].RA > 40.5))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54793") && ((tempdata_avg->records[i].RA < 45.5 && tempdata_avg->records[i].RA > 44.5))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54793") && ((tempdata_avg->records[i].RA < 48.25 && tempdata_avg->records[i].RA > 47.0))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54793") && ((tempdata_avg->records[i].RA < 77.0 && tempdata_avg->records[i].RA > 75.0))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54793") && ((tempdata_avg->records[i].RA < 79.25 && tempdata_avg->records[i].RA > 78.0))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54820") && ((tempdata_avg->records[i].RA < 66.25 && tempdata_avg->records[i].RA > 65.75))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54820") && ((tempdata_avg->records[i].RA < 79.75 && tempdata_avg->records[i].RA > 78.75))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54820") && ((tempdata_avg->records[i].RA < 88.25 && tempdata_avg->records[i].RA > 87.0))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54813") && ((tempdata_avg->records[i].RA < 88.00 && tempdata_avg->records[i].RA > 87.5))) moonflag = 1;
				if(!strcmp(daydata->mjd,"54785") && ((tempdata_avg->records[i].RA < 79.75 && tempdata_avg->records[i].RA > 79.0))) moonflag = 1;
			}
// ---------------------- N1 ends

//				Remove alien spacecraft !!
					if(i > 0 && !moonflag
						&& tempdata_avg->records[i].DEC < decmax
						&& tempdata_avg->records[i].DEC > decmin)
					{
						if (fabs(tempdata_avg->records[i].DEC - tempdata_avg->records[i-1].DEC) < max_dec_step
						    && fabs(tempdata_avg->records[i].DEC - tempdata_avg->records[i-1].DEC) > min_dec_step)
						{
						    jj++;
						}
					}

					if(i == 0)
						jj++;				
				}
			}

			daydata->numRecords = jj;

			free(tempdata_avg->records);
		}

		free(tempdata_avg);
	} 
}


int fluxwappdata_writechan(FluxWappData * wappdata, int chan)
{
	int m;
	int count = 0;

	for (m=0; m<wappdata->numDays; m++)
	{
		int k;
		FILE *file;
		int numRecords;
		char filename[64+1];
		char tempstring[6];
		FluxDayData * daydata = &wappdata->daydata[m];

		//SSG
		if (multibeam)
		{
			sprintf(tempstring,"beam%d",m%7);
		        sprintf(filename, "%s/%s/balance%04i.dat", daydata->mjd, tempstring, chan);
		}
		else
		{
			sprintf(filename, "%s/%s/balance%04i.dat", daydata->mjd, wappdata->wapp, chan);
		}

		//SSG
		file = fopen(filename, "w");
		if (file == NULL)
		{
			printf("ERROR: can't open output file %s\n", filename);
			continue;
		}
		else
		{
			fprintf(file, "#RA DEC AST I Q U V\n");
		}

		numRecords = daydata->numRecords;

		for (k=0; k<numRecords; k++)
		{
			fluxrecord_write(&daydata->records[k], file);
		}

		fclose(file);
		count++;
	}

	return count;
}


int fluxwappdata_writechan_binary(FluxWappData * wappdata, int chan)
{
	int m;
	int count;

	count = 0;
	for (m=0; m<wappdata->numDays; m++)
	{
		int k;
		FILE *file;
		int numRecords;
		char filename[64+1];
		char tempstring[6];
		FluxDayData * daydata = &wappdata->daydata[m];

		//SSG
		if (multibeam)
		{
			sprintf(tempstring,"beam%d",m%7);
	        	sprintf(filename, "%s/%s/balance%04i.dat", daydata->mjd, tempstring, chan);
		}
		else
		{
			sprintf(filename, "%s/%s/balance%04i.dat", daydata->mjd, wappdata->wapp, chan);
		}

		//SSG
		file = fopen(filename, "wb");
		if (file == NULL) 
		{
			printf("ERROR: can't open output file %s\n", filename);
			continue;
		}

		numRecords = daydata->numRecords;

		for (k=0; k<numRecords; k++) 
		{
			fluxrecord_write_binary(&daydata->records[k], file);
		}

		fclose(file);
		count++;
	}

	return count;
}


int fluxwappdata_writechan_binary_single(FluxWappData * wappdata, int chan)
{
	int m;
	int count;

	count = 0;
	for (m=0; m<wappdata->numDays; m++)
	{
		int k;
		FILE *file;
		FILE *configfile;
		int numRecords;
		char filename[64+1];
		char tempstring[6];
		char configfilename[64+1];
		FluxDayData * daydata = &wappdata->daydata[m];

		//SSG
		if (multibeam)
		{
			sprintf(tempstring,"beam%d",m%7);
			sprintf(filename, "%s/%s/balance.dat", daydata->mjd, tempstring);
			sprintf(configfilename, "%s/%s/balance.dat_cfg", daydata->mjd, tempstring);
		}
		else
		{
			sprintf(filename, "%s/%s/balance.dat", daydata->mjd, wappdata->wapp);
			sprintf(configfilename, "%s/%s/balance.dat_cfg", daydata->mjd, tempstring);
		}

		configfile = fopen(configfilename, "w");
		if (configfile == NULL)
		{
			printf("ERROR: unable to open file %s\n", filename);
		}
		else
		{
			fprintf(configfile, "%d\n", numRecords);
		}

		fclose(configfile);

		//SSG
		file = fopen(filename, "wb");
		if (file == NULL)
		{
			printf("ERROR: can't open output file %s\n", filename);
			continue;
		}

		numRecords = daydata->numRecords;

		for (k=0; k<numRecords; k++)
		{
			fluxrecord_write_binary(&daydata->records[k], file);
		}

		fclose(file);
		count++;
	}

	return count;
}


int fluxrecord_write(FluxRecord * pRec, FILE * file)
{
	return fprintf(file,"%2.8f %2.8f %8.2f %4.6f %4.6f %4.6f %4.6f\n",
		pRec->RA, pRec->DEC, pRec->AST,
		pRec->stokes.I, pRec->stokes.Q, pRec->stokes.U, pRec->stokes.V);
}


int fluxrecord_write_binary(FluxRecord * pRec, FILE * file)
{
	int s = 0;
	s += fwrite(&pRec->RA, sizeof(float), 1, file);
	s += fwrite(&pRec->DEC, sizeof(float), 1, file);
	s += fwrite(&pRec->AST, sizeof(float), 1, file);
	s += fwrite(&pRec->stokes.I, sizeof(float), 1, file);
	s += fwrite(&pRec->stokes.Q, sizeof(float), 1, file);
	s += fwrite(&pRec->stokes.U, sizeof(float), 1, file);
	s += fwrite(&pRec->stokes.V, sizeof(float), 1, file);

	return s;
}

