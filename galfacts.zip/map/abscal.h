#include "common.h"
#include "fluxdata.h"
#include "map.h"

#ifndef _ABSCAL_H
#define _ABSCAL_H

void abs_cal(FluxWappData * wappdata,int chan, MapMetaData *md);
#endif
