#include "fluxdata.h"
#include "common.h"

//void write_scanline_data(SpecRecord dataset[], int size, int lowchan, int highchan, float decmin, float decmax, int scan_count_thresh);
void determine_scan_lines(FluxWappData *wappdata, float decmin, float decmax);

