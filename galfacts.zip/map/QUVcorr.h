#include "common.h"
#include "fluxdata.h"
#include "map.h"

#ifndef _QUVCORR_H
#define _QUVCORR_H

void QUVcorr(FluxWappData * wappdata, int chan, MapMetaData *md);
#endif
