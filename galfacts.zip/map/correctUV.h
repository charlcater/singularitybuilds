#include "common.h"
#include "fluxdata.h"
#include "map.h"

#ifndef _CORRECTUV_H
#define _CORRECTUV_H

void correct_UV(FluxWappData * wappdata, int chan, MapMetaData *md);

#endif
