#include "common.h"
#include "fluxdata.h"
#include "map.h"

#ifndef _CORRECTIONS_H
#define _CORRECTIONS_H

void corrections(FluxWappData * wappdata, int chan, MapMetaData *md);
#endif
