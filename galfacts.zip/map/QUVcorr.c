#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "QUVcorr.h"

//contains all the corrections derived from the CALIBRATOR sources. Since the multiple steps in the correction all rely on original data its better to deal with them all at a same place. Otherwise it is messy to pass the same data back and forth between different functions

static inline float guess_alfa_angle(const char * field_name)
{
	char field_direction = field_name[0];
	char field_number = field_name[1];

	if (field_direction == 'Z')
	{
		return 0.0;
	}

	if (field_number == '1')
	{
		return 0.0;
	}

	return M_PI/3.0;
}

void QUVcorr(FluxWappData * wappdata, int chan, MapMetaData *md)
{
	//currently only works for full channel and not channel averages 
	//this is because the table contains MAX_CHANNEL values
	//For channel averages should we average the table values ??


	int d,i,b;
	printf("DEBUG: numDays (in QUVcorr) = %d\n", wappdata->numDays);
	for(d=0; d<wappdata->numDays; d++)
        {
		int i_corr_loaded = 0;
		int q_corr_loaded = 0;
		int u_corr_loaded = 0;
		int v_corr_loaded = 0;
		FluxDayData * daydata = &wappdata->daydata[d];
		
		const float alfa_angle = guess_alfa_angle(md->field);
		const float position_angle = alfa_angle - M_PI/4.0;
		printf("INFO: alfa_angle = %f\n", alfa_angle);
		printf("INFO: position_angle = %f\n", position_angle);

		//read the tables
		float qc[7][MAX_CHANNELS];
		float uc[7][MAX_CHANNELS];
		float vc[7][MAX_CHANNELS];
		float Pc[7][MAX_CHANNELS];
		float spec_I[7][MAX_CHANNELS];
		float pa[7][MAX_CHANNELS];

		int c;
		FILE *table;
		char filename[64];
		sprintf(filename,"%s.Qcorr.txt",md->field);

		table = fopen(filename,"r");
		if(table == NULL)
		{
			printf("ERROR: unable to open file %s\n", filename);
			//return;
		}
		else
		{
			q_corr_loaded = 1;
			for(i = 0; i < MAX_CHANNELS; i++)
			{
				fscanf(table ,"%d",&c);
				//printf("%d ",c);
				for(b=0;b<7;b++)
				{
					fscanf(table ,"%f",&qc[b][i]);
					//printf("%f ",qc[b][i]);
				}
				//printf("\n");
			}
			fclose(table);

			if(md->avg)
			{	
				int j;
				for(j = md->avg_lowchan;j < md->avg_highchan;j+=md->avg)
				{
					int k;
					for(k = j+1;k<j+md->avg;k++)
					{
						for(b=0;b<7;b++)
						{
							qc[b][j]+=qc[b][k];
						}
					}
					for(b=0;b<7;b++)
					{
						qc[b][j]/=md->avg;
					}
				}
			}
			if( chan == 0 ) {
				int k = 0;
				for(k = md->avg_lowchan;k< md->avg_highchan;k++)
				{
					for(b=0;b<7;b++)
					{
						qc[b][0]+=qc[b][k];
					}
				}
				for(b=0;b<7;b++)
				{
					qc[b][0]/=(md->avg_highchan - md->avg_lowchan);
				}
			}

		}

		//sprintf(filename,"Ucorr.dat");
		sprintf(filename,"%s.Ucorr.txt",md->field);
		table = fopen(filename,"r");
		if(table == NULL)
		{
			printf("ERROR: unable to open file %s\n", filename);
			//return;
		}
		else
		{
			u_corr_loaded = 1;
			for(i = 0; i < MAX_CHANNELS; i++)
			{
				fscanf(table ,"%d",&c);
				//printf("%d ",c);
				for(b=0;b<7;b++)
				{
					fscanf(table ,"%f",&uc[b][i]);
					//printf("%f ",uc[b][i]);
				}
				//printf("\n");
			}
			fclose(table);

			if(md->avg)
			{	
				int j;
				for(j = md->avg_lowchan;j < md->avg_highchan;j+=md->avg)
				{
					int k;
					for(k = j+1;k<j+md->avg;k++)
					{
						for(b=0;b<7;b++)
						{
							uc[b][j]+=uc[b][k];
						}
					}
					for(b=0;b<7;b++)
					{
						uc[b][j]/=md->avg;
					}
				}
			}
			if( chan == 0 ) {
				int k = 0;
				for(k = md->avg_lowchan;k< md->avg_highchan;k++)
				{
					for(b=0;b<7;b++)
					{
						uc[b][0]+=uc[b][k];
					}
				}
				for(b=0;b<7;b++)
				{
					uc[b][0]/=(md->avg_highchan - md->avg_lowchan);
				}
			}

		}

		//sprintf(filename,"Vcorr.dat");
		sprintf(filename,"%s.Vcorr.txt",md->field);
		table = fopen(filename,"r");
		if(table == NULL)
		{
			printf("ERROR: unable to open file %s\n", filename);
			//return;
		}
		else
		{
			v_corr_loaded = 1;
			for(i = 0; i < MAX_CHANNELS; i++)
			{
				fscanf(table ,"%d",&c);
				//printf("%d ",c);
				for(b=0;b<7;b++)
				{
					fscanf(table ,"%f",&vc[b][i]);
					//printf("%f ",vc[b][i]);
				}
				//printf("\n");
			}
			fclose(table);

			if(md->avg)
			{	
				int j;
				for(j = md->avg_lowchan;j < md->avg_highchan;j+=md->avg)
				{
					int k;
					for(k = j+1;k<j+md->avg;k++)
					{
						for(b=0;b<7;b++)
						{
							vc[b][j]+=vc[b][k];
						}
					}
					for(b=0;b<7;b++)
					{
						vc[b][j]/=md->avg;
					}
				}
			}
			if( chan == 0 ) {
				int k = 0;
				for(k = md->avg_lowchan;k< md->avg_highchan;k++)
				{
					for(b=0;b<7;b++)
					{
						vc[b][0]+=vc[b][k];
					}
				}
				for(b=0;b<7;b++)
				{
					vc[b][0]/=(md->avg_highchan - md->avg_lowchan);
				}
			}

		}

		/* not needed for now can be enabled later
		sprintf(filename,"Pcorr.dat");
		table = fopen(filename,"r");
		if(table == NULL)
		{
			printf("ERROR: unable to open file %s\n", filename);
			return;
		}
		else
		{
			for(i = 0; i < MAX_CHANNELS; i++)
			{
				fscanf(table ,"%d",&c);
				for(b=0;b<7;b++)
				{
					fscanf(table ,"%f",&Pc[b][i]);
				}
			}
			fclose(table);

			if(md->avg)
			{	
				int j;
				for(j = md->avg_lowchan;j < md->avg_highchan;j+=md->avg)
				{
					int k;
					for(k = j+1;k<j+md->avg;k++)
					{
						for(b=0;b<7;b++)
						{
							Pc[b][j]+=Pc[b][k];
						}
					}
					for(b=0;b<7;b++)
					{
						Pc[b][j]/=md->avg;
					}
				}
			}
			if( chan == 0 ) {
				int k = 0;
				for(k = md->avg_lowchan;k< md->avg_highchan;k++)
				{
					for(b=0;b<7;b++)
					{
						Pc[b][0]+=Pc[b][k];
					}
				}
				for(b=0;b<7;b++)
				{
					Pc[b][0]/=(md->avg_highchan - md->avg_lowchan);
				}
			}

		}

		sprintf(filename,"PAcorr.dat");
		table = fopen(filename,"r");
		if(table == NULL)
		{
			printf("ERROR: unable to open file %s\n", filename);
			return;
		}
		else
		{
			for(i = 0; i < MAX_CHANNELS; i++)
			{
				fscanf(table ,"%d",&c);
				for(b=0;b<7;b++)
				{
					fscanf(table ,"%f",&pa[b][i]);
				}
			}
			fclose(table);

			if(md->avg)
			{	
				int j;
				for(j = md->avg_lowchan;j < md->avg_highchan;j+=md->avg)
				{
					int k;
					for(k = j+1;k<j+md->avg;k++)
					{
						for(b=0;b<7;b++)
						{
							pa[b][j]+=pa[b][k];
						}
					}
					for(b=0;b<7;b++)
					{
						pa[b][j]/=md->avg;
					}
				}
			}
			if( chan == 0 ) {
				int k = 0;
				for(k = md->avg_lowchan;k< md->avg_highchan;k++)
				{
					for(b=0;b<7;b++)
					{
						pa[b][0]+=pa[b][k];
					}
				}
				for(b=0;b<7;b++)
				{
					pa[b][0]/=(md->avg_highchan - md->avg_lowchan);
				}
			}

		}
		*/
		//apply the corrections
		int r = daydata->numRecords;
		int beam;
                if(!strcmp(wappdata->wapp,"multibeam"))
                {
                        beam = d%7;
                }
                else
                {
                        beam = atoi(&wappdata->wapp[4]);
                }
		
		//pa[beam][chan] = pa[beam][chan]*M_PI/180.0;
		// default for now
		pa[beam][chan] = position_angle;

		//plugging in these for now
		Pc[beam][chan] = 1.0;

		float qcc = 0.0;
		if (q_corr_loaded) {
			qcc = qc[beam][chan];
		}

		float ucc = 0.0;
		if (u_corr_loaded) {
			ucc = uc[beam][chan];
		}

		float vcc = 0.0;
		if (v_corr_loaded) {
			vcc = vc[beam][chan];
		}

		printf("DEBUG: Rotating records...%d\n", r);

		for(i=0;i<r;i++)
		{
			daydata->records[i].stokes.Q = daydata->records[i].stokes.Q - qcc*daydata->records[i].stokes.I;
			daydata->records[i].stokes.U = daydata->records[i].stokes.U - ucc*daydata->records[i].stokes.I;
			daydata->records[i].stokes.V = daydata->records[i].stokes.V - vcc*daydata->records[i].stokes.I;
			float Q = daydata->records[i].stokes.Q;
			float U = daydata->records[i].stokes.U;
			daydata->records[i].stokes.Q = Pc[beam][chan]*(Q*cos(2*pa[beam][chan])-U*sin(2*pa[beam][chan]));
			daydata->records[i].stokes.U = Pc[beam][chan]*(Q*sin(2*pa[beam][chan])+U*cos(2*pa[beam][chan]));
		}
        }
}
