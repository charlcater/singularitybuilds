#include "common.h"
#include "fluxdata.h"
#include "map.h"

#ifndef _SPEC_CORR_H
#define _SPEC_CORR_H

void spec_corr(FluxWappData * wappdata, int chan, MapMetaData *md);
#endif
