#include "common.h"
#include "fluxdata.h"

void vleakagefit(FluxWappData *,int chan);

